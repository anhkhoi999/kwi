
local keys = {
    "Windy1",

    "Windy2",
    
    "d45b38c1-68d7-4eb4-b490-3d082ec4e91a",
    
    "anything?",

    "Windy3",

    "Windy4"
}

local keyCheck
for i,v in pairs(keys) do
    if counter == #keys then
    --not whitelisted!
    keys = ""
    game.Players.LocalPlayer:Kick("Not a valid key!")
    else
        if v == _G.Key then
            --Whitelisted!
            print("Successfully whitelisted!")
            keyCheck = _G.Key
            keys = ""
            local windy = loadstring(game:HttpGet("https://raw.githubusercontent.com/MaGiXxScripter0/keysystemv2api/master/ui/notify_ui.lua"))()
windy.New("Whitelist Successfully !! ", 5)
            wait(2)
 _G.WINDYKAITUN = true
_G.Mics = {
    ["Remove Terrain"] = false,
    ["White Screen"] = false,
    ["Disabled Notify"] = false,
    ["Auto Rejoin"] = false,
    ["Delay Per Rejoin"] = 3600,
    ["Max-Distance Bypass TP"] = 1500
}
_G.Settings = {
    ["Team"] = "Pirates",
    ["Enabled Skip Farm"] = true,
    ["Auto Do Level Stuff"] = true,
    ["Auto Collect Fruit"] = true,
    ["Auto Store Fruit"] = true,
    ["Auto Mastery Melee"] = true,
    ["Auto Saber"] = true,
    ["Auto Pole"] = true,
    ["Auto New World 2"] = true,
    ["Auto Bartilo Quest"] = true,
    ["Auto Rengoku"] = true,
    ["Auto Flamingo Access"] = true,
    ["Auto Midnight Blade"] = true,
    ["Auto Buy 3 Legendary Sword"] = true,
    ["Auto Buy Legendary Haki"] = true,
    ["Auto Buy All When Level More Than 350"] = true,
    ["Auto New World 3"] = true,
    ["Auto Yama"] = true,
    ["Auto Tushita"] = true,
    ["Auto Soul Guitar"] = true
}
_G.Windy_Key = "WindyHubFreeKey"
loadstring(game:HttpGet("https://raw.githubusercontent.com/ItzWindy01/WindyXBypass/main/Kaitun.lua"))()
        end
    end
end

while true do
    if _G.Key == keyCheck then
        --Not spoofed
    else
        game.Players.LocalPlayer:Kick("do not try and spoof your key")
    end
    wait()
end